# IdeeRoth AG - Parts shared by all pages

Page: https://www.iro.swiss/
Language: English (the German version is in ../de/00-gemeinsam.md)

### Main navigation (header)

[Company](https://www.iro.swiss/#unternehmen) | [Expertise](https://www.iro.swiss/#kompetenzen) | [Services](https://www.iro.swiss/#leistungen) | [Team](https://www.iro.swiss/#team) | [Contact](https://www.iro.swiss/kontakt.html)

### Menu (phone and tablet)

Link: “Company” → https://www.iro.swiss/#unternehmen

Link: “Expertise” → https://www.iro.swiss/#kompetenzen

Link: “Services” → https://www.iro.swiss/#leistungen

Link: “Team” → https://www.iro.swiss/#team

Link: “Careers” → https://www.iro.swiss/karriere.html

Link: “Contact” → https://www.iro.swiss/kontakt.html

Language DE EN

[Start project](https://www.iro.swiss/#kontakt)

### Footer of the subpages

Graphic: “NAFEMS member” → https://www.nafems.org

Graphic: “Training company - Wir machen Profis” → https://www.iro.swiss/karriere.html#lehrstelle

[Company](https://www.iro.swiss/#unternehmen) | [Expertise](https://www.iro.swiss/#kompetenzen) | [Services](https://www.iro.swiss/#leistungen)

[Team](https://www.iro.swiss/#team) | [Careers](https://www.iro.swiss/karriere.html) | [Contact](https://www.iro.swiss/kontakt.html)

IdeeRoth AG  
Hafenstrasse 62  
CH-8590 Romanshorn +41 71 855 88 55 info@iro.swiss

© 2026 IdeeRoth AG [Legal notice](https://www.iro.swiss/impressum.html) [Privacy](https://www.iro.swiss/datenschutz.html) Cookie settings

### Cookie notice (shown on the first visit)

We use Google Analytics to understand how our website is used - only with your consent. You can withdraw your choice at any time via “Cookie settings” in the footer.

Privacy policy

Button: “Decline”

Button: “Accept”
