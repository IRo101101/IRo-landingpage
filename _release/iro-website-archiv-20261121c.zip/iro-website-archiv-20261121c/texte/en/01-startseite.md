# IdeeRoth AG - Home

Page: https://www.iro.swiss/
Language: English (the German version is in ../de/01-startseite.md)

## Page title and description (search engines, social media)

- Page title: IdeeRoth AG - Product development from idea to series production
- Description: IdeeRoth AG (iro.swiss): specialist in product development from Romanshorn - engineering, simulation (FEM/CFD), development and in-house prototyping. Develop more from less.
- Social media title: IdeeRoth AG - Product development from idea to series production
- Social media description: Specialist in product development from Romanshorn - engineering, simulation, development and in-house prototyping.
- Social media image description: Open glass doors of the IdeeRoth AG building onto the terrace

## Hero

![Backlight through the open door of the company building](../../bilder/fotos/07.jpg)

- 20+ years · of experience
- 1 partner · from sketch to prototype
- 130 dB · the boss's laugh when it clicks

### Develop more from less.

From the first idea to series production.

From the first idea through to series development - engineering, simulation, development and prototyping under one roof.

Button: “Open apprenticeship” → https://www.iro.swiss/karriere.html#lehrstelle

Button: “Explore expertise”

Button: “Five steps”

## Company

IdeeRoth AG · Swiss

### Specialist in product development.

![Glass front and terrace of the company building](../../bilder/fotos/08.jpg)

![Employee with documents in the workshop](../../bilder/fotos/05.jpg)

![Meeting at a table with a monitor](../../bilder/fotos/10.jpg)

![Employee at the monitor](../../bilder/fotos/04.jpg)

![The team discussing documents at the long table](../../bilder/fotos/27.jpg)

![Employee with a coffee cup](../../bilder/fotos/18.jpg)

![Open glass door to the workshop](../../bilder/fotos/06.jpg)

![Employee sketching at a workstation](../../bilder/fotos/15.jpg)

![Employee at the lathe](../../bilder/fotos/20.jpg)

![View through the glass front of a machine tool](../../bilder/fotos/02.jpg)

About us

- Swiss engineered
- 3D-CAD
- FEM / CFD
- Prototyping
- Vocational training

A product's success lies in its simplicity. That is why, for us, “Develop more from less” means fewer parts, less complexity and less effort on the way to series production. Whatever a product does not need, we leave out.

## Expertise

![Two employees discussing a concept on a tablet](../../bilder/fotos/09.jpg)

#### Ideation

Reducing ideas to the essentials.

Develop more from less - ideas become viable concepts. We assess feasibility, cost and benefit before detailed design begins: with rough sketches, first 3D drafts and a cost estimate based on the key parameters.

Link: “To step 01 · Idea”

![Design meeting with 3D CAD on screen](../../bilder/fotos/11.jpg)

#### Development

Design, material and manufacturing considered together.

Our team knows materials and manufacturing processes from practice, from injection-moulded to milled parts. Methods such as FMEA, DFM and design reviews catch errors during development, before they reach the customer.

Link: “To step 04 · Development”

![Office with workstations and monitors](../../bilder/fotos/13.jpg)

#### Simulation

Calculating before building.

In our projects, simulation runs alongside the design work. FEM shows how parts behave under load, and CFD how air and liquids flow. We are a member of NAFEMS, the international association for engineering analysis and simulation, which keeps us up to date on methods and validation.

Link: “To step 03 · Simulation”

![Employee at the milling machine](../../bilder/fotos/14.jpg)

#### Prototyping

Touch, test, improve before tooling is ordered.

Early tests on real parts show whether a concept works. You hold your product in your hands and test it in use before expensive production tooling is made. That lowers risk and cost.

Link: “To step 05 · Prototype”

## Services

Five steps to series production

#### 01 / Idea

You bring an idea, a wish or a problem. We structure the requirements, think through variants and evaluate them with you. That way you decide on a clear basis which path we pursue together.

Deliverable: Concept with variants, feasibility assessment and cost estimate

#### 02 / Engineering

With modern CAD software we create detailed designs and photorealistic renderings. They form the basis for simulation and for the first prototypes.

Deliverable: 3D model, drawings and renderings

#### 03 / Simulation

We run FEM and CFD simulations, optimise highly stressed parts and provide verification for series use.

Deliverable: Analysis report with verification

#### 04 / Development

We take the concept to production readiness step by step. Risk analyses and design-for-manufacturing checks reduce the risk of costly changes when series production starts.

Deliverable: Production-ready documentation

#### 05 / Prototype

Our workshop builds functional samples quickly. For every process we work with suppliers who are among the best in their field: CNC milling and turning, additive manufacturing, welding, casting.

Deliverable: Functional sample for testing

![Three employees inspecting parts](../../bilder/fotos/19.jpg)

![Employee sketching at a workstation](../../bilder/fotos/15.jpg)

![Meeting at a table with a monitor](../../bilder/fotos/10.jpg)

![Employee at the 3D printer](../../bilder/fotos/21.jpg)

![3D printer printing Shore hardness samples with the IRo logo](../../bilder/fotos/22.jpg)

## Team

### We give our best to find your solution.

A team of specialists in design engineering, simulation and prototyping - united by precision, experience and the ambition to develop more from less.

![The IdeeRoth AG team in conversation](../../bilder/fotos/16.jpg)

01 // Vision

Better products for life.

With this vision we solve problems with our ideas. In our customers' innovation network we are a long-term partner - sustainable, ecological and efficient.

> “Develop more from less - the simplest solution is usually the best.” Alain Roth · Founder, IdeeRoth AG

02 // Mission

Develop more from less.

Our team supports customers in product development and improves their competitiveness. We value:

- An independent and neutral perspective
- Focused implementation that delivers results
- A strong technological and business network
- Industry-specific application expertise

03 // Principles

Responsible, honest, loyal.

Employees are our most valuable asset. We offer attractive workplaces, support people through targeted training and aim for long-term partnership.

- We honour our agreements.
- We act fast and decisively and see change as an opportunity.
- We are creative and continuously seek precisely engineered solutions.
- We communicate openly and honestly to build trust.

04 // Vocational training

We train young talent - Konstrukteur/-in EFZ apprenticeship 2027.

There is a lot of talk about the skills shortage. We prefer to do something about it.

About the apprenticeship

05 // Discretion

Your product carries your name.

We develop behind the scenes and treat customer relationships, projects and product images as confidential, which is why you will not find any references here.

- We do not compete with our customers.
- Our reward: you come back with your next development project.

06 // Industries

From start-ups to industrial companies.

We work wherever parts go into series production. Our customers come from sectors such as:

- Toolmaking
- Plastic injection moulding, die casting and sheet metal fabrication
- Machine and plant engineering, for example filling systems for liquids and solids
- Food processing machines for households, food service and industry
- Pharmaceuticals and medical technology

07 // Working together

How a project begins.

Every project starts with a conversation, at your site or ours. On request, we sign a non-disclosure agreement beforehand. In this conversation we work out in detail what your project could involve.

- You then receive a quote setting out effort and schedule, and a dedicated point of contact guides you through the entire project.
- On request, we take on additional tasks in the project, such as the requirements specification, project management or support through to production release.
- Together with our sister company, we organise small batches, procurement and, if you wish, series production. You receive the parts through IdeeRoth AG, have a single point of contact and have nothing else to worry about.

## Contact (closing section)

![Exterior of the company building with a path](../../bilder/fotos/17.jpg)

Link: “Company”

Link: “Expertise”

Link: “Services”

Link: “Team”

Link: “Careers” → https://www.iro.swiss/karriere.html

Link: “Contact” → https://www.iro.swiss/kontakt.html

Graphic: “NAFEMS member” → https://www.nafems.org

Graphic: “Training company - Wir machen Profis” → https://www.iro.swiss/karriere.html#lehrstelle

+41 71 855 88 55 info@iro.swiss IdeeRoth AG  
Hafenstrasse 62  
CH-8590 Romanshorn

### Let's talk about your project.

Button: “Send an e-mail” → mailto:info@iro.swiss?subject=Project%20enquiry%20IdeeRoth%20AG

Button: “Call” → tel:+41718558855

[Legal notice](https://www.iro.swiss/impressum.html) | [Privacy](https://www.iro.swiss/datenschutz.html) | Cookie settings

© 2026 IdeeRoth AG
