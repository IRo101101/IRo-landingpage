# IdeeRoth AG - Careers

Page: https://www.iro.swiss/karriere.html
Language: English (the German version is in ../de/03-karriere.md)

## Page title and description (search engines, social media)

- Page title: Careers - IdeeRoth AG
- Description: Careers and vocational training at IdeeRoth AG in Romanshorn: open apprenticeship Konstrukteur/-in EFZ 2027 and unsolicited applications welcome.
- Social media title: Careers - IdeeRoth AG
- Social media description: Careers and vocational training at IdeeRoth AG in Romanshorn: open apprenticeship Konstrukteur/-in EFZ 2027 and unsolicited applications welcome.

## Introduction

Careers

### Good people are a good fit for us.

A steep learning curve through varied tasks and projects with a high degree of personal responsibility. Integration into a dynamic team and a culture of openness, active participation and teamwork. Regular team and company events strengthen our sense of togetherness.

## 01 // Careers

### We train talent.

There is a lot of talk about the skills shortage. We do something about it - we train apprentices.

IdeeRoth AG trains design engineers (Konstrukteur/-in EFZ, Swiss Federal VET Diploma) and gives young people the tools for a demanding technical career. From day one, our apprentices work on real projects and learn design, calculation and development in the everyday work of an engineering office.

Step by step, they grow into independent professionals. What they gain with us stays with them - and with Swiss industry.

That way we don't just secure our own next generation. We make a concrete contribution against the skills shortage. Not by complaining, but by training.

## 02 // Careers

### Apprenticeship 2027

Wir suchen dich

Develop more from less - entwickle aus weniger mehr. Dieser Leitsatz prägt unsere Arbeit als Spezialist für Produktentwicklung. Wir lösen Probleme durch kreative Ansätze und sind als langfristiger Partner fest in den Innovationsnetzwerken unserer Kunden verankert. Dabei verbinden wir Herzblut mit Zuverlässigkeit und arbeiten konsequent nachhaltig, ökologisch und effizient.

Wir setzen auf wertvolles, gesundes Wachstum. Das gilt für unsere Kundenprojekte genauso wie für unsere Unternehmenskultur. Als attraktiver Arbeitgeber fördern wir Talente und fordern Bestleistungen. Wenn diese Leidenschaft auf unsere strategische Weitsicht trifft, entsteht echter, nachhaltiger Wert.

Im Sommer 2027 kann deine berufliche Laufbahn bei der IdeeRoth AG starten mit einer

#### Lehre als Konstrukteur/-in EFZ (Eintritt 1. August 2027)

##### Deine Aufgaben bestehen aus:

- Entwickeln und Konstruieren von Bauteilen und ganzen Baugruppen
- Erstellen von Konstruktionszeichnungen
- Erstellen von technischen Dokumentationen
- Technische Abklärungen innerhalb unseres Betriebs

##### Damit überzeugst du uns:

- Freude an Mathematik, Geometrie und Physik
- Interesse an technischen Zusammenhängen und Mechanik
- Technisches Verständnis
- Fähigkeit, räumlich zu denken
- Freude an der Arbeit am Computer
- Abgeschlossene Oberstufe mit guten Noten in Niveau M oder E
- Geduld, Ausdauer und Konzentration
- Teamfähigkeit und Zuverlässigkeit

##### Das kannst du von uns erwarten:

Eine abwechslungsreiche 4-jährige Ausbildung, bei der deine persönliche Entwicklung im Fokus steht. Wir unterstützen dich aktiv dabei, mehr als nur das Minimum zu erreichen und über deine Grenzen hinauszuwachsen. Freue dich auf ein innovatives, ambitioniertes Umfeld und eine steile Lernkurve in spannenden Projekten. Ein offenes Miteinander, Raum für deine eigenen Ideen sowie coole Teamevents sind bei uns feste Bestandteile des Arbeitsalltags.

Gerne laden wir dich bei Interesse auf abwechslungsreiche Schnuppertage ein. Mach den ersten Schritt in deine berufliche Zukunft und melde dich bei uns.

Weitere Informationen über deinen zukünftigen Beruf findest du unter [www.berufsberatung.ch](https://www.berufsberatung.ch)

Du erreichst uns unter +41 71 855 88 55 für einen ersten Austausch und darfst dann gerne deine vollständigen Bewerbungsunterlagen (inkl. Foto) an info@iro.swiss versenden.

Wir freuen uns auf dich!

Button: “Jetzt bewerben” → mailto:info@iro.swiss?subject=Bewerbung%20Lehrstelle%20Konstrukteur%2F-in%20EFZ

## 03 // Careers

### Unsolicited application

Nothing suitable right now? No problem - you are talented, and you know that best yourself. Taking initiative has always been one of our favourite qualities. If you bring the right qualities, we would love to hear from you.

Please send your complete application documents to:

IdeeRoth AG · Engineering Development Prototypes  
Hafenstrasse 62 · CH-8590 Romanshorn  
info@iro.swiss  
For more information, Alain Roth is happy to help: +41 71 855 88 55

Button: “Apply now” → mailto:info@iro.swiss?subject=Application%20IdeeRoth%20AG

Button: “Back to home” → https://www.iro.swiss/
