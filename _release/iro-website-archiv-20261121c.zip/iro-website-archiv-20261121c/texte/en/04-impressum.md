# IdeeRoth AG - Legal notice

Page: https://www.iro.swiss/impressum.html
Language: English (the German version is in ../de/04-impressum.md)

## Page title and description (search engines, social media)

- Page title: Legal notice - IdeeRoth AG
- Description: Legal notice of IdeeRoth AG, Hafenstrasse 62, 8590 Romanshorn.
- Social media title: Legal notice - IdeeRoth AG
- Social media description: Legal notice of IdeeRoth AG, Hafenstrasse 62, 8590 Romanshorn.

## Introduction

Legal notice

### Legal notice

## 01 // Legal notice

### Contact address

IdeeRoth AG  
Hafenstrasse 62  
CH-8590 Romanshorn  
Phone +41 71 855 88 55  
Mail info@iro.swiss  
Web [www.iro.swiss](https://www.iro.swiss)  
UID CHE-407.745.534

## 02 // Legal notice

### Copyright

The copyright and all other rights to content, images, photos or other files on the website belong exclusively to IdeeRoth AG or the specifically named rights holders. Written consent from the copyright holders must be obtained in advance for the reproduction of any elements.

Some of the photos on this website have been edited with AI.

## 03 // Legal notice

### Disclaimer

IdeeRoth AG provides general information about the company, its activities and services on this website as an initial orientation. Although the information is kept up to date, IdeeRoth AG assumes no responsibility for the timeliness, correctness or completeness of the data provided. Liability claims for damages of a material or immaterial nature arising from access to or use of the published information are excluded to the extent permitted by law.

## 04 // Legal notice

### Liability for links

References and links to third-party websites lie outside our area of responsibility. We accept no responsibility for such websites. Access to and use of such websites is at the user's own risk.

Button: “Back to home” → https://www.iro.swiss/
