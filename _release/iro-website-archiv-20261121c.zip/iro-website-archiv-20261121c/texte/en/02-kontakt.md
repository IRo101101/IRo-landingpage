# IdeeRoth AG - Contact

Page: https://www.iro.swiss/kontakt.html
Language: English (the German version is in ../de/02-kontakt.md)

## Page title and description (search engines, social media)

- Page title: Contact and directions - IdeeRoth AG
- Description: Contact IdeeRoth AG in Romanshorn: address, phone, e-mail, route planning and directions by car, train and ferry from Friedrichshafen.
- Social media title: Contact and directions - IdeeRoth AG
- Social media description: Contact IdeeRoth AG in Romanshorn: address, phone, e-mail, route planning and directions by car, train and ferry from Friedrichshafen.

## Introduction

Contact

### How to reach us.

Hafenstrasse 62 is right by Romanshorn harbour, a ten-minute walk from the railway station and the ferry. Write to us, call us or come by.

## 01 // Contact

### Contact address

IdeeRoth AG  
Hafenstrasse 62  
CH-8590 Romanshorn  
Phone +41 71 855 88 55  
Mail info@iro.swiss  
Contact person Alain Roth

Button: “Send an e-mail” → mailto:info@iro.swiss?subject=Enquiry%20IdeeRoth%20AG

Button: “Call” → tel:+41718558855

## 02 // Contact

### Hafenstrasse 62, right at the harbour.

Button: “Directions in Google Maps” → https://www.google.com/maps/dir/?api=1&destination=IdeeRoth+AG,+Hafenstrasse+62,+8590+Romanshorn

Timetables [SBB timetable](https://www.sbb.ch/en?nach=8590+Romanshorn,+Hafenstrasse+62) [Ferry timetable](https://www.bodensee-schiffe.ch/faehre/fahrplan/)

The destination is already entered in each link. Google Maps uses your location as the starting point or asks for it. In the SBB timetable you enter your departure point yourself.

## 03 // Directions

### How to find us.

#### By car

##### To the Hubkreisel roundabout in Romanshorn

- From Amriswil and Weinfelden: main road 14 to the Hubkreisel.
- From Zurich, Winterthur and Frauenfeld: A7 to exit 6 Kreuzlingen Süd, then main road 13 along the lake to Romanshorn. Kreuzlingerstrasse leads to the Hubkreisel.
- From St. Gallen and Austria: A1 to the Meggenhus junction, then the A23 towards Arbon to its end. Turn left onto main road 13 to Romanshorn. Arbonerstrasse leads to the Hubkreisel.

##### From the Hubkreisel to us

- About 700 m along Bahnhofstrasse towards the railway station.
- At the junction with Salmsacherstrasse turn left into Hafenstrasse.
- Follow Hafenstrasse for about 650 m to its end. Number 62, the building of Restaurant Panem, is on the left.
- Public parking is available right by the harbour.

#### By train and bus

- Trains and buses stop at Romanshorn railway station.
- Take the pedestrian underpass to the harbour side, then follow the quay along the harbour basin to Hafenstrasse.
- The building of Restaurant Panem stands diagonally opposite on the right. About ten minutes on foot.

#### By boat

- The ferry from Friedrichshafen docks right next to the railway station. The crossing takes about 45 minutes.
- In the summer season the scheduled boats also call here.
- From the landing stage walk towards the station to the corner of the harbour basin, turn right and follow the quay to Hafenstrasse. About ten minutes on foot.

#### Entrance and deliveries

- Our office is in the building of Restaurant Panem, Hafenstrasse 62.
- The entrance is on the west side of the building, away from the harbour.
- Take the stairs up to the raised ground floor, then follow the corridor to the left.
- Deliveries also go through this entrance.

Button: “Back to home” → https://www.iro.swiss/
