# IdeeRoth AG - Karriere

Seite: https://www.iro.swiss/karriere.html
Sprache: Deutsch (die englische Fassung steht in ../en/03-karriere.md)

## Seitentitel und Beschreibung (Suchmaschinen, Social Media)

- Seitentitel: Karriere - IdeeRoth AG
- Beschreibung: Karriere und Berufsbildung bei der IdeeRoth AG in Romanshorn: offene Lehrstelle Konstrukteur/-in EFZ 2027 und Initiativbewerbungen willkommen.
- Titel Social Media: Karriere - IdeeRoth AG
- Beschreibung Social Media: Karriere und Berufsbildung bei der IdeeRoth AG in Romanshorn: offene Lehrstelle Konstrukteur/-in EFZ 2027 und Initiativbewerbungen willkommen.

## Einleitung

Karriere

### Gute Leute passen gut zu uns.

Eine steile Lernkurve durch abwechslungsreiche Aufgaben und Projekte mit hoher Eigenverantwortung. Einbindung in ein dynamisches Team und eine Kultur der Offenheit, aktiven Mitgestaltung und Teamarbeit. Regelmässige Team- und Firmenevents festigen den Zusammenhalt.

## 01 // Karriere

### Wir bilden aus.

Vom Fachkräftemangel wird viel geredet. Wir tun etwas dagegen - und bilden aus.

Die IdeeRoth AG bildet Konstrukteurinnen und Konstrukteure EFZ aus und gibt jungen Menschen das Rüstzeug für eine anspruchsvolle technische Laufbahn. Unsere Lernenden arbeiten von Beginn an an realen Projekten mit und lernen Konstruktion, Berechnung und Entwicklung im Alltag eines Ingenieurbüros.

Schritt für Schritt werden sie so zu eigenständigen Fachleuten. Was sie bei uns erwerben, bleibt ihnen - und dem Werkplatz Schweiz - erhalten.

So sichern wir nicht nur unseren eigenen Nachwuchs, sondern leisten einen konkreten Beitrag gegen den Fachkräftemangel. Nicht mit Klagen, sondern mit Ausbildung.

## 02 // Karriere

### Lehrstelle 2027

Wir suchen dich

Develop more from less - entwickle aus weniger mehr. Dieser Leitsatz prägt unsere Arbeit als Spezialist für Produktentwicklung. Wir lösen Probleme durch kreative Ansätze und sind als langfristiger Partner fest in den Innovationsnetzwerken unserer Kunden verankert. Dabei verbinden wir Herzblut mit Zuverlässigkeit und arbeiten konsequent nachhaltig, ökologisch und effizient.

Wir setzen auf wertvolles, gesundes Wachstum. Das gilt für unsere Kundenprojekte genauso wie für unsere Unternehmenskultur. Als attraktiver Arbeitgeber fördern wir Talente und fordern Bestleistungen. Wenn diese Leidenschaft auf unsere strategische Weitsicht trifft, entsteht echter, nachhaltiger Wert.

Im Sommer 2027 kann deine berufliche Laufbahn bei der IdeeRoth AG starten mit einer

#### Lehre als Konstrukteur/-in EFZ (Eintritt 1. August 2027)

##### Deine Aufgaben bestehen aus:

- Entwickeln und Konstruieren von Bauteilen und ganzen Baugruppen
- Erstellen von Konstruktionszeichnungen
- Erstellen von technischen Dokumentationen
- Technische Abklärungen innerhalb unseres Betriebs

##### Damit überzeugst du uns:

- Freude an Mathematik, Geometrie und Physik
- Interesse an technischen Zusammenhängen und Mechanik
- Technisches Verständnis
- Fähigkeit, räumlich zu denken
- Freude an der Arbeit am Computer
- Abgeschlossene Oberstufe mit guten Noten in Niveau M oder E
- Geduld, Ausdauer und Konzentration
- Teamfähigkeit und Zuverlässigkeit

##### Das kannst du von uns erwarten:

Eine abwechslungsreiche 4-jährige Ausbildung, bei der deine persönliche Entwicklung im Fokus steht. Wir unterstützen dich aktiv dabei, mehr als nur das Minimum zu erreichen und über deine Grenzen hinauszuwachsen. Freue dich auf ein innovatives, ambitioniertes Umfeld und eine steile Lernkurve in spannenden Projekten. Ein offenes Miteinander, Raum für deine eigenen Ideen sowie coole Teamevents sind bei uns feste Bestandteile des Arbeitsalltags.

Gerne laden wir dich bei Interesse auf abwechslungsreiche Schnuppertage ein. Mach den ersten Schritt in deine berufliche Zukunft und melde dich bei uns.

Weitere Informationen über deinen zukünftigen Beruf findest du unter [www.berufsberatung.ch](https://www.berufsberatung.ch)

Du erreichst uns unter +41 71 855 88 55 für einen ersten Austausch und darfst dann gerne deine vollständigen Bewerbungsunterlagen (inkl. Foto) an info@iro.swiss versenden.

Wir freuen uns auf dich!

Schaltfläche: «Jetzt bewerben» → mailto:info@iro.swiss?subject=Bewerbung%20Lehrstelle%20Konstrukteur%2F-in%20EFZ

## 03 // Karriere

### Initiativbewerbung

Aktuell nichts Passendes dabei? Kein Problem - denn du bist talentiert und weisst es selbst am besten. Eigeninitiative war schon immer eine unserer Lieblingseigenschaften. Wenn du passende Qualitäten mitbringst, hören wir gerne von dir.

Bitte sende deine vollständigen Bewerbungsunterlagen an:

IdeeRoth AG · Konstruktion Entwicklung Prototypen  
Hafenstrasse 62 · CH-8590 Romanshorn  
info@iro.swiss  
Auskunft erteilt dir gerne Alain Roth: +41 71 855 88 55

Schaltfläche: «Jetzt bewerben» → mailto:info@iro.swiss?subject=Bewerbung%20IdeeRoth%20AG

Schaltfläche: «Zurück zur Startseite» → https://www.iro.swiss/
