# IdeeRoth AG - Fehlerseite 404

Seite: https://www.iro.swiss/404.html
Sprache: Deutsch (die englische Fassung steht in ../en/06-fehlerseite-404.md)

## Seitentitel und Beschreibung (Suchmaschinen, Social Media)

- Seitentitel: Seite nicht gefunden - IdeeRoth AG
- Beschreibung: Diese Seite gibt es nicht. IdeeRoth AG, Produktentwicklung aus der Schweiz.

## Einleitung

Fehler 404

### Diese Seite gibt es nicht.

Die Adresse ist vielleicht falsch geschrieben, oder die Seite ist umgezogen. Die Startseite und die Kontaktseite führen Sie weiter.

Schaltfläche: «Zur Startseite» → https://www.iro.swiss/

Schaltfläche: «Kontakt» → https://www.iro.swiss/kontakt.html
