# IdeeRoth AG - Startseite

Seite: https://www.iro.swiss/
Sprache: Deutsch (die englische Fassung steht in ../en/01-startseite.md)

## Seitentitel und Beschreibung (Suchmaschinen, Social Media)

- Seitentitel: IdeeRoth AG - Produktentwicklung von der Idee bis zur Serie
- Beschreibung: IdeeRoth AG (iro.swiss): Spezialanbieterin für Produktentwicklung aus Romanshorn - Konstruktion, Simulation (FEM/CFD), Entwicklung und Prototyping im eigenen Haus. Aus weniger mehr entwickeln.
- Titel Social Media: IdeeRoth AG - Produktentwicklung von der Idee bis zur Serie
- Beschreibung Social Media: Spezialanbieterin für Produktentwicklung aus Romanshorn - Konstruktion, Simulation, Entwicklung und Prototyping im eigenen Haus.
- Bildbeschreibung Social Media: Offene Glastüren des Firmengebäudes der IdeeRoth AG zur Terrasse

## Startbild

![Gegenlicht durch die offene Tür des Firmengebäudes](../../bilder/fotos/07.jpg)

- 20+ Jahre · Erfahrung
- 1 Adresse · von Skizze bis Prototyp
- 130 dB · lacht der Chef, wenn der Zwanziger fällt

### Aus weniger mehr entwickeln.

Von der ersten Idee bis zur Serie.

Von der ersten Idee bis zur fertigen Serienentwicklung - Konstruktion, Simulation, Entwicklung und Prototyping unter einem Dach.

Schaltfläche: «Offene Lehrstelle» → https://www.iro.swiss/karriere.html#lehrstelle

Schaltfläche: «Kompetenzen entdecken»

Schaltfläche: «Fünf Schritte»

## Unternehmen

IdeeRoth AG · Swiss

### Spezialanbieterin für Produktentwicklung.

![Glasfront und Terrasse des Firmengebäudes](../../bilder/fotos/08.jpg)

![Mitarbeiter mit Unterlagen in der Werkstatt](../../bilder/fotos/05.jpg)

![Besprechung am Tisch mit Bildschirm](../../bilder/fotos/10.jpg)

![Mitarbeiterin am Bildschirm](../../bilder/fotos/04.jpg)

![Das Team bespricht Unterlagen am langen Tisch](../../bilder/fotos/27.jpg)

![Mitarbeiter mit Kaffeetasse](../../bilder/fotos/18.jpg)

![Offene Glastür zur Werkstatt](../../bilder/fotos/06.jpg)

![Mitarbeiter beim Skizzieren am Arbeitsplatz](../../bilder/fotos/15.jpg)

![Mitarbeiter an der Drehmaschine](../../bilder/fotos/20.jpg)

![Blick durch die Glasfront auf eine Werkzeugmaschine](../../bilder/fotos/02.jpg)

Über uns

- Swiss engineered
- 3D-CAD
- FEM / CFD
- Prototyping
- Berufsbildung

Der Erfolg eines Produkts steckt in seiner Einfachheit. Darum heisst «Aus weniger mehr entwickeln» für uns: weniger Teile, weniger Komplexität, weniger Aufwand bis zur Serie. Was ein Produkt nicht braucht, lassen wir weg.

## Kompetenzen

![Zwei Mitarbeiter besprechen ein Konzept am Tablet](../../bilder/fotos/09.jpg)

#### Ideation

Ideen auf das Wesentliche bringen.

Aus weniger mehr entwickeln - Ideen werden zu tragfähigen Konzepten. Wir prüfen Machbarkeit, Kosten und Nutzen, bevor die Detailkonstruktion beginnt: mit groben Skizzen, ersten 3D-Entwürfen und einer Kostenschätzung anhand der wichtigsten Parameter.

Verweis: «Zu Schritt 01 · Idee»

![Konstruktionsbesprechung mit 3D-CAD am Bildschirm](../../bilder/fotos/11.jpg)

#### Entwicklung

Konstruktion, Werkstoff und Fertigung zusammen gedacht.

Unser Team kennt Werkstoffe und Fertigungsverfahren aus der Praxis, vom Spritzgussteil bis zum Frästeil. Methoden wie FMEA, DFM und Designreviews fangen Fehler in der Entwicklung ab und nicht erst beim Kunden.

Verweis: «Zu Schritt 04 · Entwicklung»

![Büro mit Arbeitsplätzen und Bildschirmen](../../bilder/fotos/13.jpg)

#### Simulation

Rechnen, bevor gebaut wird.

Simulation läuft bei uns parallel zur Konstruktion. FEM zeigt, wie Bauteile unter Last reagieren, und CFD, wie Luft und Flüssigkeiten strömen. Wir sind Mitglied von NAFEMS, der internationalen Vereinigung für Berechnung und Simulation, und bleiben dadurch bei Methoden und Validierung auf dem aktuellen Stand.

Verweis: «Zu Schritt 03 · Simulation»

![Mitarbeiter an der Fräsmaschine](../../bilder/fotos/14.jpg)

#### Prototyping

Anfassen, testen, verbessern, bevor Werkzeuge bestellt werden.

Frühe Tests an echten Teilen zeigen, ob ein Konzept funktioniert. Sie prüfen Ihr Produkt in der Hand und im Einsatz, bevor teure Serienwerkzeuge entstehen. Das senkt Risiko und Kosten.

Verweis: «Zu Schritt 05 · Prototyp»

## Leistungen

In fünf Schritten zur Serie

#### 01 / Idee

Sie bringen eine Idee, einen Wunsch oder ein Problem. Wir ordnen die Anforderungen, denken Varianten durch und bewerten sie mit Ihnen. So entscheiden Sie auf klarer Grundlage, welchen Weg wir zusammen weitergehen.

Ergebnis: Konzept mit Varianten, Beurteilung der Machbarkeit und Kostenrahmen

#### 02 / Konstruktion

Mit moderner CAD-Software entstehen Detailkonstruktionen und fotorealistische Darstellungen. Sie sind die Basis für Simulation und für erste Prototypen.

Ergebnis: 3D-Modell, Zeichnungen und Darstellungen

#### 03 / Simulation

Wir führen FEM- und CFD-Simulationen durch, optimieren stark belastete Bauteile und liefern Nachweise für den Serieneinsatz.

Ergebnis: Berechnungsbericht mit Nachweis

#### 04 / Entwicklung

Wir führen das Konzept Schritt für Schritt zur Serienreife. Risikoanalysen und Prüfungen auf Fertigbarkeit senken das Risiko teurer Änderungen beim Serienanlauf.

Ergebnis: Serienreife Unterlagen

#### 05 / Prototyp

Unsere Werkstatt baut Funktionsmuster in kurzer Zeit. Für jedes Verfahren arbeiten wir mit Zulieferern, die in ihrer Disziplin zu den besten gehören: CNC-Fräsen und -Drehen, additive Fertigung, Schweissen, Giessen.

Ergebnis: Funktionsmuster zum Testen

![Drei Mitarbeiter prüfen Bauteile](../../bilder/fotos/19.jpg)

![Mitarbeiter beim Skizzieren am Arbeitsplatz](../../bilder/fotos/15.jpg)

![Besprechung am Tisch mit Bildschirm](../../bilder/fotos/10.jpg)

![Mitarbeiter am 3D-Drucker](../../bilder/fotos/21.jpg)

![3D-Drucker druckt Shore-Härtemuster mit IRo-Logo](../../bilder/fotos/22.jpg)

## Team

### Wir geben unser Bestes für Ihre Lösung.

Ein Team aus Fachleuten für Konstruktion, Simulation und Prototypenbau - vereint durch Präzision, Erfahrung und den Anspruch, aus weniger mehr zu entwickeln.

![Das Team der IdeeRoth AG im Gespräch](../../bilder/fotos/16.jpg)

01 // Vision

Better products for life.

Mit dieser Vision lösen wir Probleme mit unseren Ideen. Im Innovationsnetzwerk unserer Kunden sind wir langfristige Partnerin - nachhaltig, ökologisch und effizient.

> «Aus weniger mehr entwickeln - die einfachste Lösung ist meist die beste.» Alain Roth · Gründer, IdeeRoth AG

02 // Mission

Aus weniger mehr entwickeln.

Unser Team unterstützt Kunden bei der Produktentwicklung und verbessert so deren Wettbewerbsfähigkeit. Wir legen Wert auf:

- Eine unabhängige und neutrale Sichtweise
- Eine zielgerichtete Umsetzung und Resultaterreichung
- Einen starken technologischen und betriebswirtschaftlichen Leistungsverbund
- Branchenspezifisches Anwendungsfachwissen

03 // Leitbild

Verantwortungsbewusst, ehrlich, loyal.

Mitarbeitende sind unser wichtigstes Gut. Wir bieten attraktive Arbeitsplätze, fördern sie gezielt durch Weiterbildung und streben eine langjährige Partnerschaft an.

- Wir halten Vereinbarungen ein.
- Wir handeln schnell und entschlossen und sehen Veränderung als Chance.
- Wir sind kreativ und suchen laufend nach präzis ausgearbeiteten Lösungen.
- Wir kommunizieren offen und ehrlich, um Vertrauen zu schaffen.

04 // Berufsbildung

Wir bilden aus - Lehrstelle Konstrukteur/-in EFZ 2027.

Vom Fachkräftemangel wird viel geredet. Wir tun etwas dagegen.

Zur Lehrstelle

05 // Diskretion

Ihr Produkt trägt Ihren Namen.

Wir entwickeln im Hintergrund und behandeln Kundenbeziehungen, Projekte und Produktbilder vertraulich, darum zeigen wir hier keine Referenzen.

- Wir treten nicht gegen unsere Kunden an.
- Unser Lohn: Sie kommen mit Ihrer nächsten Entwicklung wieder.

06 // Branchen

Vom Start-up bis zum Industrieunternehmen.

Wir arbeiten überall, wo Teile in Serie entstehen. Unsere Kunden kommen unter anderem aus diesen Bereichen:

- Werkzeugbau
- Kunststoffspritzguss, Druckguss und Blechbearbeitung
- Maschinen- und Anlagenbau, etwa für die Abfüllung von Flüssigkeiten und Feststoffen
- Maschinen für die Lebensmittelverarbeitung in Haushalt, Gastronomie und Industrie
- Pharma und Medizinaltechnik

07 // Zusammenarbeit

So beginnt ein Projekt.

Am Anfang steht ein Gespräch, bei Ihnen oder bei uns. Auf Wunsch unterzeichnen wir vorher eine Geheimhaltungsvereinbarung. In diesem Gespräch klären wir ausführlich, was Ihr Projekt beinhalten könnte.

- Danach erhalten Sie eine Offerte mit Aufwand und Terminen, und eine feste Ansprechperson begleitet Sie durch das ganze Projekt.
- Auf Wunsch übernehmen wir weitere Aufgaben im Projekt, etwa das Lastenheft, die Projektleitung oder die Begleitung bis zur Serienfreigabe.
- Kleinserien, Beschaffung und, wenn Sie möchten, auch die Serie organisieren wir mit unserer Schwesterfirma. Sie erhalten die Teile über die IdeeRoth AG, haben eine einzige Ansprechperson und müssen sich um nichts weiter kümmern.

## Kontakt (Abspann)

![Aussenansicht des Firmengebäudes mit Weg](../../bilder/fotos/17.jpg)

Verweis: «Unternehmen»

Verweis: «Kompetenzen»

Verweis: «Leistungen»

Verweis: «Team»

Verweis: «Karriere» → https://www.iro.swiss/karriere.html

Verweis: «Kontakt» → https://www.iro.swiss/kontakt.html

Grafik: «NAFEMS-Mitglied» → https://www.nafems.org

Grafik: «Lehrbetrieb - Wir machen Profis» → https://www.iro.swiss/karriere.html#lehrstelle

+41 71 855 88 55 info@iro.swiss IdeeRoth AG  
Hafenstrasse 62  
CH-8590 Romanshorn

### Sprechen wir über Ihr Projekt.

Schaltfläche: «E-Mail schreiben» → mailto:info@iro.swiss?subject=Projektanfrage%20IdeeRoth%20AG

Schaltfläche: «Anrufen» → tel:+41718558855

[Impressum](https://www.iro.swiss/impressum.html) | [Datenschutz](https://www.iro.swiss/datenschutz.html) | Cookie-Einstellungen

© 2026 IdeeRoth AG
