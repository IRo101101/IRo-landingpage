# IdeeRoth AG - Kontakt

Seite: https://www.iro.swiss/kontakt.html
Sprache: Deutsch (die englische Fassung steht in ../en/02-kontakt.md)

## Seitentitel und Beschreibung (Suchmaschinen, Social Media)

- Seitentitel: Kontakt und Anreise - IdeeRoth AG
- Beschreibung: Kontakt zur IdeeRoth AG in Romanshorn: Adresse, Telefon, E-Mail, Routenplanung und Anreise mit Auto, Bahn und Fähre ab Friedrichshafen.
- Titel Social Media: Kontakt und Anreise - IdeeRoth AG
- Beschreibung Social Media: Kontakt zur IdeeRoth AG in Romanshorn: Adresse, Telefon, E-Mail, Routenplanung und Anreise mit Auto, Bahn und Fähre ab Friedrichshafen.

## Einleitung

Kontakt

### So erreichen Sie uns.

Die Hafenstrasse 62 liegt am Hafen von Romanshorn, zehn Gehminuten von Bahnhof und Fähre. Schreiben Sie uns, rufen Sie an oder kommen Sie vorbei.

## 01 // Kontakt

### Kontaktadresse

IdeeRoth AG  
Hafenstrasse 62  
CH-8590 Romanshorn  
Tel +41 71 855 88 55  
Mail info@iro.swiss  
Ansprechperson Alain Roth

Schaltfläche: «E-Mail schreiben» → mailto:info@iro.swiss?subject=Anfrage%20IdeeRoth%20AG

Schaltfläche: «Anrufen» → tel:+41718558855

## 02 // Kontakt

### Hafenstrasse 62, direkt am Hafen.

Schaltfläche: «Route in Google Maps» → https://www.google.com/maps/dir/?api=1&destination=IdeeRoth+AG,+Hafenstrasse+62,+8590+Romanshorn

Fahrpläne [SBB-Fahrplan](https://www.sbb.ch/de?nach=8590+Romanshorn,+Hafenstrasse+62) [Fährfahrplan](https://www.bodensee-schiffe.ch/faehre/fahrplan/)

Das Ziel ist in jedem Link bereits eingetragen. Google Maps nimmt Ihren Standort als Start oder fragt danach. Im SBB-Fahrplan tragen Sie den Abfahrtsort selbst ein.

## 03 // Anreise

### So finden Sie zu uns.

#### Mit dem Auto

##### Zum Hubkreisel in Romanshorn

- Von Amriswil und Weinfelden: Hauptstrasse 14 bis zum Hubkreisel.
- Von Zürich, Winterthur und Frauenfeld: A7 bis Ausfahrt 6 Kreuzlingen Süd, dann Hauptstrasse 13 dem See entlang nach Romanshorn. Die Kreuzlingerstrasse führt zum Hubkreisel.
- Von St. Gallen und aus Österreich: A1 bis zur Verzweigung Meggenhus, dann A23 Richtung Arbon bis zum Ende. Links auf die Hauptstrasse 13 nach Romanshorn. Die Arbonerstrasse führt zum Hubkreisel.

##### Vom Hubkreisel zu uns

- Rund 700 m auf der Bahnhofstrasse Richtung Bahnhof.
- Bei der Kreuzung mit der Salmsacherstrasse links in die Hafenstrasse.
- Der Hafenstrasse rund 650 m bis ans Ende folgen. Die Nummer 62, das Gebäude des Restaurants Panem, liegt links.
- Öffentliche Parkplätze gibt es direkt am Hafen.

#### Mit Bahn und Bus

- Züge und Busse halten am Bahnhof Romanshorn.
- Durch die Personenunterführung auf die Hafenseite, dann auf dem Quai dem Hafenbecken entlang bis zur Hafenstrasse.
- Das Gebäude des Restaurants Panem steht schräg rechts gegenüber. Rund zehn Minuten zu Fuss.

#### Mit dem Schiff

- Die Fähre aus Friedrichshafen legt direkt beim Bahnhof an. Die Überfahrt dauert rund 45 Minuten.
- Im Sommerhalbjahr legen hier auch die Kursschiffe an.
- Vom Anleger Richtung Bahnhof bis zur Ecke des Hafenbeckens, dort rechts und auf dem Quai bis zur Hafenstrasse. Rund zehn Minuten zu Fuss.

#### Eingang und Anlieferung

- Unser Büro liegt im Gebäude des Restaurants Panem, Hafenstrasse 62.
- Der Eingang liegt auf der Westseite des Gebäudes, vom Hafen abgewandt.
- Im Treppenhaus hinauf ins Hochparterre, dann links den Flur entlang.
- Anlieferungen bitte ebenfalls über diesen Eingang.

Schaltfläche: «Zurück zur Startseite» → https://www.iro.swiss/
