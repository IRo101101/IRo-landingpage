# IdeeRoth AG - Gemeinsame Teile aller Seiten

Seite: https://www.iro.swiss/
Sprache: Deutsch (die englische Fassung steht in ../en/00-gemeinsam.md)

### Hauptnavigation (Kopfzeile)

[Unternehmen](https://www.iro.swiss/#unternehmen) | [Kompetenzen](https://www.iro.swiss/#kompetenzen) | [Leistungen](https://www.iro.swiss/#leistungen) | [Team](https://www.iro.swiss/#team) | [Kontakt](https://www.iro.swiss/kontakt.html)

### Menü (Handy und Tablet)

Verweis: «Unternehmen» → https://www.iro.swiss/#unternehmen

Verweis: «Kompetenzen» → https://www.iro.swiss/#kompetenzen

Verweis: «Leistungen» → https://www.iro.swiss/#leistungen

Verweis: «Team» → https://www.iro.swiss/#team

Verweis: «Karriere» → https://www.iro.swiss/karriere.html

Verweis: «Kontakt» → https://www.iro.swiss/kontakt.html

Sprache DE EN

[Projekt starten](https://www.iro.swiss/#kontakt)

### Footer der Unterseiten

Grafik: «NAFEMS-Mitglied» → https://www.nafems.org

Grafik: «Lehrbetrieb - Wir machen Profis» → https://www.iro.swiss/karriere.html#lehrstelle

[Unternehmen](https://www.iro.swiss/#unternehmen) | [Kompetenzen](https://www.iro.swiss/#kompetenzen) | [Leistungen](https://www.iro.swiss/#leistungen)

[Team](https://www.iro.swiss/#team) | [Karriere](https://www.iro.swiss/karriere.html) | [Kontakt](https://www.iro.swiss/kontakt.html)

IdeeRoth AG  
Hafenstrasse 62  
CH-8590 Romanshorn +41 71 855 88 55 info@iro.swiss

© 2026 IdeeRoth AG [Impressum](https://www.iro.swiss/impressum.html) [Datenschutz](https://www.iro.swiss/datenschutz.html) Cookie-Einstellungen

### Cookie-Hinweis (erscheint beim ersten Besuch)

Wir verwenden Google Analytics, um die Nutzung unserer Website zu verstehen - nur mit Ihrer Einwilligung. Sie können Ihre Wahl jederzeit über «Cookie-Einstellungen» im Footer widerrufen.

Datenschutzerklärung

Schaltfläche: «Ablehnen»

Schaltfläche: «Akzeptieren»
