# IdeeRoth AG - Privacy policy

Page: https://www.iro.swiss/datenschutz.html
Language: English (the German version is in ../de/05-datenschutz.md)

## Page title and description (search engines, social media)

- Page title: Privacy policy - IdeeRoth AG
- Description: Privacy policy of IdeeRoth AG: server log files, cookies and consent, Google Analytics only with opt-in, your rights.
- Social media title: Privacy policy - IdeeRoth AG
- Social media description: Privacy policy of IdeeRoth AG: server log files, cookies and consent, Google Analytics only with opt-in, your rights.

## Introduction

Privacy

### Privacy policy

IdeeRoth AG is committed to transparency. Our customers' trust matters to us. This policy explains what data this website processes and how.

## 01 // Privacy policy

### Responsible party

IdeeRoth AG  
Hafenstrasse 62  
CH-8590 Romanshorn  
Phone: +41 71 855 88 55  
E-Mail: datenschutz@iro.swiss

## 02 // Privacy policy

### Principle

This website is a static information site. Without your consent, we use no analytics cookies and no tracking. Fonts are self-hosted - no external font services are used. With your explicit consent we use Google Analytics to measure website reach (see the “Google Analytics” section). Apart from the technically necessary server log files (see the “Server log files” section), we only process personal data that you provide to us voluntarily, for example by e-mail or telephone.

## 03 // Privacy policy

### Server log files

When you visit this website, our hosting provider automatically stores technical access data that your browser transmits, in so-called server log files:

- Name of the page accessed, date and time
- Amount of data transferred and message about successful access
- Browser type and version, operating system
- Referrer URL and IP address

These data are used solely for the technically secure operation, stability and optimisation of the website and are not merged with other data sources. Under the GDPR, the legal basis is our legitimate interest in the secure operation of the site (Art. 6(1)(f) GDPR). The log files are kept only as long as this purpose requires and are then deleted.

## 04 // Privacy policy

### Hosting

This website is hosted by a hosting provider in Switzerland. The provider processes the server log files described above on our behalf.

## 05 // Privacy policy

### Cookies and consent

On your first visit we ask for your consent via a notice. Only if you choose “Accept” are analytics cookies set and Google Analytics loaded. If you choose “Decline”, none of this happens. We store your choice and, if you switch languages, your language preference locally in your browser (localStorage, no cookie, nothing is transmitted). If you decline later, we delete the analytics cookies. You can change or withdraw it at any time via the “Cookie settings” link in the footer.

## 06 // Privacy policy

### Google Analytics

With your consent we use Google Analytics 4, a web analytics service of Google Ireland Limited (Gordon House, Barrow Street, Dublin 4, Ireland). Google Analytics uses cookies and similar technologies to evaluate the use of the website. The information generated (including page views, approximate location, device and browser) is transmitted to Google and stored there. This may involve a transfer to the USA. According to Google, Google Analytics 4 does not log or store IP addresses. The approximate location is only derived from them.

The recipient is Google Ireland Limited in Ireland. For transfers to Google LLC in the USA, Google states that it relies on the Swiss-U.S. Data Privacy Framework and on standard contractual clauses. Google deletes the data automatically after the retention period set in our account.

The purpose is the statistical evaluation of website use to improve our offering. The legal basis is your consent (Art. 6(1)(a) GDPR and the Swiss Data Protection Act). You can withdraw your consent at any time with effect for the future via “Cookie settings” in the footer.

Google opt-out add-on: [tools.google.com/dlpage/gaoptout](https://tools.google.com/dlpage/gaoptout) · Google privacy policy: [policies.google.com/privacy](https://policies.google.com/privacy)

## 07 // Privacy policy

### Contact by e-mail or phone

If you contact us by e-mail or telephone, the details you provide (e.g. name, e-mail address, message) are stored for the purpose of handling your enquiry and any follow-up questions. We do not pass on these data without your consent. Under the GDPR, the legal basis is handling your enquiry or our legitimate interest in replying (Art. 6(1)(b) and (f) GDPR). We delete the details once they are no longer needed for this purpose and no statutory retention obligation applies.

## 08 // Privacy policy

### Data security

This website is delivered encrypted via SSL/TLS (recognisable by the lock icon and “https” in the address bar). We take technical and organisational security measures to protect your data against loss, manipulation and unauthorised access.

## 09 // Privacy policy

### Route planning

Our contact page does not embed a map. The route and timetable links lead to Google Maps, SBB and the ferry operator. Data only flows to these providers once you click a link. From then on their provisions apply.

## 10 // Privacy policy

### Your rights

You have the right to access, rectify and erase the personal data stored about you, to restrict its processing and to receive or transfer your data, and you may object to processing at any time. You can withdraw any consent at any time. To exercise these rights, please contact us:

datenschutz@iro.swiss

You can also contact the Federal Data Protection and Information Commissioner (FDPIC), or in the EU the data protection authority of your country: [www.edoeb.admin.ch](https://www.edoeb.admin.ch)

## 11 // Privacy policy

### Amendments

We may adapt this privacy policy from time to time so that it always meets current legal requirements or reflects changes to our services. The version in force at the time of your visit applies.

Last updated: 21 November 2026.

Button: “Back to home” → https://www.iro.swiss/
