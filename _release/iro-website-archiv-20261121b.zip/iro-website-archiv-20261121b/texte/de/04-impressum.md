# IdeeRoth AG - Impressum

Seite: https://www.iro.swiss/impressum.html
Sprache: Deutsch (die englische Fassung steht in ../en/04-impressum.md)

## Seitentitel und Beschreibung (Suchmaschinen, Social Media)

- Seitentitel: Impressum - IdeeRoth AG
- Beschreibung: Impressum der IdeeRoth AG, Hafenstrasse 62, 8590 Romanshorn.
- Titel Social Media: Impressum - IdeeRoth AG
- Beschreibung Social Media: Impressum der IdeeRoth AG, Hafenstrasse 62, 8590 Romanshorn.

## Einleitung

Impressum

### Impressum

## 01 // Impressum

### Kontaktadresse

IdeeRoth AG  
Hafenstrasse 62  
CH-8590 Romanshorn  
Tel +41 71 855 88 55  
Mail info@iro.swiss  
Web [www.iro.swiss](https://www.iro.swiss)

## 02 // Impressum

### Urheberrechte

Die Urheber- und alle anderen Rechte an Inhalten, Bildern, Fotos oder anderen Dateien auf der Website gehören ausschliesslich der IdeeRoth AG oder den speziell genannten Rechtsinhabern. Für die Reproduktion jeglicher Elemente ist die schriftliche Zustimmung der Urheberrechtsträger im Voraus einzuholen.

## 03 // Impressum

### Haftungsausschluss

Die IdeeRoth AG bietet auf dieser Seite allgemeine Informationen über die Firma, ihre Aktivitäten und Dienstleistungen als erste Orientierungshilfe an. Obwohl die Informationen aktuell gehalten werden, übernimmt die IdeeRoth AG keine Verantwortung für die Aktualität, Richtigkeit und Vollständigkeit der aufgeführten Daten. Haftungsansprüche wegen Schäden materieller oder immaterieller Art, die aus dem Zugriff oder der Nutzung der veröffentlichten Informationen entstehen, werden ausgeschlossen, soweit das Gesetz dies zulässt.

## 04 // Impressum

### Haftung für Links

Verweise und Links auf Webseiten Dritter liegen ausserhalb unseres Verantwortungsbereichs. Es wird jegliche Verantwortung für solche Webseiten abgelehnt. Der Zugriff und die Nutzung solcher Webseiten erfolgen auf eigene Gefahr der Nutzerin oder des Nutzers.

Schaltfläche: «Zurück zur Startseite» → https://www.iro.swiss/
