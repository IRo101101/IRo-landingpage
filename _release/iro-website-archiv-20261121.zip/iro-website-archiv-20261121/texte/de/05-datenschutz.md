# IdeeRoth AG - Datenschutz

Seite: https://www.iro.swiss/datenschutz.html
Sprache: Deutsch (die englische Fassung steht in ../en/05-datenschutz.md)

## Seitentitel und Beschreibung (Suchmaschinen, Social Media)

- Seitentitel: Datenschutzerklärung - IdeeRoth AG
- Beschreibung: Datenschutzerklärung der IdeeRoth AG: Server-Logfiles, Cookies und Einwilligung, Google Analytics nur mit Opt-in, Ihre Rechte.
- Titel Social Media: Datenschutzerklärung - IdeeRoth AG
- Beschreibung Social Media: Datenschutzerklärung der IdeeRoth AG: Server-Logfiles, Cookies und Einwilligung, Google Analytics nur mit Opt-in, Ihre Rechte.

## Einleitung

Datenschutz

### Datenschutzerklärung

Die IdeeRoth AG arbeitet mit hoher Transparenz. Das Vertrauen unserer Kunden ist uns wichtig. Diese Erklärung informiert, welche Daten diese Website verarbeitet und wie.

## 01 // Datenschutz

### Verantwortliche Stelle

IdeeRoth AG  
Hafenstrasse 62  
CH-8590 Romanshorn  
Telefon: +41 71 855 88 55  
E-Mail: datenschutz@iro.swiss

## 02 // Datenschutz

### Grundsatz

Diese Website ist eine statische Informationsseite. Ohne Ihre Einwilligung setzen wir keine Analyse-Cookies und kein Tracking ein. Schriften sind selbst gehostet - es werden keine externen Schriftdienste aufgerufen. Mit Ihrer ausdrücklichen Einwilligung verwenden wir Google Analytics zur Reichweitenmessung (siehe Abschnitt «Google Analytics»). Abgesehen von den technisch nötigen Server-Logfiles (Abschnitt «Server-Logfiles») verarbeiten wir personenbezogene Daten nur, wenn Sie uns diese freiwillig übermitteln, etwa per E-Mail oder Telefon.

## 03 // Datenschutz

### Server-Logfiles

Beim Besuch dieser Website speichert unser Hosting-Anbieter automatisch technische Zugriffsdaten, die Ihr Browser übermittelt, in sogenannten Server-Logfiles:

- Name der abgerufenen Seite, Datum und Uhrzeit
- Übertragene Datenmenge und Meldung über erfolgreichen Abruf
- Browsertyp und -version, Betriebssystem
- Referrer-URL und (gekürzte) IP-Adresse

Diese Daten werden ausschliesslich für den technisch sicheren Betrieb, die Stabilität und die Optimierung der Website verwendet und nicht mit anderen Datenquellen zusammengeführt. Rechtsgrundlage ist unser berechtigtes Interesse am sicheren Betrieb der Website.

## 04 // Datenschutz

### Hosting

Diese Website wird bei einem Hosting-Anbieter in der Schweiz betrieben. Der Anbieter verarbeitet die oben beschriebenen Server-Logfiles in unserem Auftrag.

## 05 // Datenschutz

### Cookies und Einwilligung

Beim ersten Besuch fragen wir Sie über einen Hinweis um Ihre Einwilligung. Erst wenn Sie «Akzeptieren» wählen, werden Analyse-Cookies gesetzt und Google Analytics geladen. Wählen Sie «Ablehnen», geschieht nichts dergleichen. Ihre Wahl und, falls Sie die Sprache wechseln, Ihre Sprachwahl speichern wir lokal in Ihrem Browser (localStorage, kein Cookie, keine Übermittlung). Lehnen Sie später ab, löschen wir die Analyse-Cookies. Sie können sie jederzeit über den Link «Cookie-Einstellungen» im Footer ändern oder widerrufen.

## 06 // Datenschutz

### Google Analytics

Mit Ihrer Einwilligung nutzen wir Google Analytics 4, einen Webanalysedienst der Google Ireland Limited (Gordon House, Barrow Street, Dublin 4, Irland). Google Analytics verwendet Cookies und ähnliche Technologien, um die Nutzung der Website auszuwerten. Die dabei erzeugten Informationen (u. a. Seitenaufrufe, ungefährer Standort, Gerät und Browser) werden an Google übertragen und dort gespeichert. Dabei kann eine Übermittlung in die USA erfolgen. Nach Angaben von Google speichert Google Analytics 4 keine IP-Adressen. Der ungefähre Standort wird daraus nur abgeleitet.

Zweck ist die statistische Auswertung der Websitenutzung zur Verbesserung unseres Angebots. Rechtsgrundlage ist Ihre Einwilligung (Art. 6 Abs. 1 lit. a DSGVO bzw. das Schweizer Datenschutzgesetz). Sie können die Einwilligung jederzeit mit Wirkung für die Zukunft widerrufen - über «Cookie-Einstellungen» im Footer.

Google Opt-out-Add-on: [tools.google.com/dlpage/gaoptout](https://tools.google.com/dlpage/gaoptout) · Datenschutz bei Google: [policies.google.com/privacy](https://policies.google.com/privacy)

## 07 // Datenschutz

### Kontaktaufnahme per E-Mail oder Telefon

Wenn Sie uns per E-Mail oder Telefon kontaktieren, werden Ihre Angaben (z. B. Name, E-Mail-Adresse, Nachricht) zum Zweck der Bearbeitung Ihrer Anfrage sowie für allfällige Anschlussfragen gespeichert. Diese Daten geben wir ohne Ihre Einwilligung nicht weiter.

## 08 // Datenschutz

### Datensicherheit

Diese Website wird verschlüsselt via SSL/TLS ausgeliefert (erkennbar am Schloss-Symbol und «https» in der Adresszeile). Wir treffen technische und organisatorische Sicherheitsmassnahmen, um Ihre Daten vor Verlust, Manipulation und unberechtigtem Zugriff zu schützen.

## 09 // Datenschutz

### Routenplanung

Unsere Kontaktseite bindet keine Karte ein. Die Routen- und Fahrplan-Links führen zu Google Maps, zur SBB und zur Fährbetreiberin. Daten fliessen erst an diese Anbieter, wenn Sie einen Link anklicken. Danach gelten deren Bestimmungen.

## 10 // Datenschutz

### Ihre Rechte

Sie haben das Recht auf Auskunft, Berichtigung, Löschung und Einschränkung der zu Ihrer Person gespeicherten Daten und können der Verarbeitung jederzeit widersprechen. Zur Ausübung dieser Rechte wenden Sie sich bitte an uns:

datenschutz@iro.swiss

## 11 // Datenschutz

### Änderungen

Wir können diese Datenschutzerklärung von Zeit zu Zeit anpassen, damit sie stets den aktuellen rechtlichen Anforderungen entspricht oder Änderungen unserer Leistungen abbildet. Für Ihren erneuten Besuch gilt die jeweils aktuelle Fassung.

Schaltfläche: «Zurück zur Startseite» → https://www.iro.swiss/
